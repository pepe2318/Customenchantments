package dev.customenchantments;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Main entry point.
 *
 * This first project package is the verified build foundation.
 * Gameplay modules (custom enchantment effects, /ce GUI, fireworks,
 * enchanted books and item application) will be added in the next source
 * iteration and tested through GitHub Actions before being called complete.
 */
public final class CustomEnchantments implements ModInitializer {
    public static final String MOD_ID = "custom_enchantments";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Custom Enchantments foundation loaded.");
    }
}
