package dev.customenchantments;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Locale;

public final class CustomEnchantments implements ModInitializer {
    public static final String MOD_ID = "custom_enchantments";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    private static final String PREFIX = "[CE] ";

    @Override
    public void onInitialize() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                applyEquipmentEffects(player);
            }
        });

        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (!(player instanceof ServerPlayerEntity serverPlayer) || world.isClient()) return;
            ItemStack tool = serverPlayer.getMainHandStack();
            int telepathy = level(tool, "Telepatía");
            int autoSmelt = level(tool, "Auto Fundir");
            if (telepathy > 0 || autoSmelt > 0) {
                collectNearbyDrops(serverPlayer, pos, telepathy > 0, autoSmelt);
            }
        });
        LOGGER.info("Custom Enchantments loaded: equipment effects, Telepatía and Auto Fundir.");
    }

    private static void applyEquipmentEffects(ServerPlayerEntity player) {
        ItemStack main = player.getMainHandStack();
        ItemStack off = player.getOffHandStack();
        applyHaste(player, main);
        if (!off.isEmpty()) applyHaste(player, off);

        ItemStack helmet = player.getInventory().getArmorStack(3);
        ItemStack chest = player.getInventory().getArmorStack(2);
        ItemStack legs = player.getInventory().getArmorStack(1);
        ItemStack boots = player.getInventory().getArmorStack(0);

        int glowing = level(helmet, "Glowing");
        if (glowing > 0) effect(player, StatusEffects.NIGHT_VISION, 260, 0);
        int shield = level(chest, "ObsidianShield");
        if (shield > 0) effect(player, StatusEffects.FIRE_RESISTANCE, 60, 0);
        int springs = level(boots, "Resortes");
        if (springs > 0) effect(player, StatusEffects.JUMP_BOOST, 60, springs - 1);
        int health = Math.max(level(helmet, "HealthBoost"), Math.max(level(chest, "HealthBoost"), Math.max(level(legs, "HealthBoost"), level(boots, "HealthBoost"))));
        if (health > 0) effect(player, StatusEffects.HEALTH_BOOST, 60, health - 1);
    }

private static void applyHaste(ServerPlayerEntity player, ItemStack stack) {
    if (stack.isEmpty()) return;

    int level = level(stack, "Haste");

    if (level > 0 && (
        stack.isOf(Items.WOODEN_PICKAXE) ||
        stack.isOf(Items.STONE_PICKAXE) ||
        stack.isOf(Items.IRON_PICKAXE) ||
        stack.isOf(Items.GOLDEN_PICKAXE) ||
        stack.isOf(Items.DIAMOND_PICKAXE) ||
        stack.isOf(Items.NETHERITE_PICKAXE) ||
        stack.isOf(Items.WOODEN_AXE) ||
        stack.isOf(Items.STONE_AXE) ||
        stack.isOf(Items.IRON_AXE) ||
        stack.isOf(Items.GOLDEN_AXE) ||
        stack.isOf(Items.DIAMOND_AXE) ||
        stack.isOf(Items.NETHERITE_AXE) ||
        stack.isOf(Items.WOODEN_SHOVEL) ||
        stack.isOf(Items.STONE_SHOVEL) ||
        stack.isOf(Items.IRON_SHOVEL) ||
        stack.isOf(Items.GOLDEN_SHOVEL) ||
        stack.isOf(Items.DIAMOND_SHOVEL) ||
        stack.isOf(Items.NETHERITE_SHOVEL)
    )) {
        effect(player, StatusEffects.HASTE, 60, level - 1);
    }
}

    private static void effect(ServerPlayerEntity player, net.minecraft.entity.effect.StatusEffect effect, int duration, int amplifier) {
        player.addStatusEffect(new StatusEffectInstance(effect, duration, amplifier, true, false, true));
    }

    private static int level(ItemStack stack, String enchantment) {
        if (stack == null || stack.isEmpty()) return 0;
        String name = stack.getName().getString().toLowerCase(Locale.ROOT);
        String target = (PREFIX + enchantment).toLowerCase(Locale.ROOT);
        if (!name.contains(target)) return 0;
        for (int i = 3; i >= 1; i--) if (name.contains(" " + roman(i).toLowerCase(Locale.ROOT))) return i;
        return 1;
    }

    private static String roman(int level) { return switch (level) { case 1 -> "I"; case 2 -> "II"; case 3 -> "III"; default -> "I"; }; }

    private static void collectNearbyDrops(ServerPlayerEntity player, BlockPos pos, boolean telepathy, int autoSmelt) {
        Box area = new Box(pos).expand(1.6);
        List<ItemEntity> drops = player.getServerWorld().getEntitiesByClass(ItemEntity.class, area, e -> e.isAlive());
        for (ItemEntity entity : drops) {
            ItemStack stack = entity.getStack();
            if (autoSmelt > 0 && Math.random() < (autoSmelt == 1 ? 0.25 : autoSmelt == 2 ? 0.50 : 1.0)) {
                entity.setStack(smeltCommonOreDrop(stack));
                stack = entity.getStack();
            }
            if (telepathy) {
                ItemStack remainder = player.getInventory().insertStack(stack.copy());
                if (remainder.isEmpty()) entity.discard();
                else entity.setStack(remainder);
            }
        }
    }

    private static ItemStack smeltCommonOreDrop(ItemStack stack) {
        Item result = null;
        if (stack.isOf(Items.RAW_IRON)) result = Items.IRON_INGOT;
        else if (stack.isOf(Items.RAW_GOLD)) result = Items.GOLD_INGOT;
        else if (stack.isOf(Items.RAW_COPPER)) result = Items.COPPER_INGOT;
        if (result != null) return new ItemStack(result, stack.getCount());
        return stack;
    }
}
