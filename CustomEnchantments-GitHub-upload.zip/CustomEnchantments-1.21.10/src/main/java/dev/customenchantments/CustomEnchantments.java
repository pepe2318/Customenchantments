package dev.customenchantments;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.ActionResult;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.entity.effect.StatusEffect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

import static net.minecraft.server.command.CommandManager.literal;

public final class CustomEnchantments implements ModInitializer {
    public static final String MOD_ID = "custom_enchantments";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static final String PREFIX = "[CE] ";
    private static final String BOOK_MARKER = "[CE-BOOK] ";
    private static final String SHOP_MARKER = "[CE-SHOP] ";
    private static final Map<UUID, RageState> RAGE = new HashMap<>();

    private record RageState(int hits, long lastHit) {}

    private enum Category {
        SWORD("espada", 20, List.of("Vampiro", "Experience", "Rage", "Viper")),
        TOOLS("herramientas", 25, List.of("Auto Fundir", "Haste", "Telepatía")),
        ARMOR("armadura", 25, List.of("Glowing", "ObsidianShield", "Resortes", "HealthBoost", "Savior", "Undyne"));

        final String command;
        final int cost;
        final List<String> enchantments;
        Category(String command, int cost, List<String> enchantments) {
            this.command = command;
            this.cost = cost;
            this.enchantments = enchantments;
        }
    }

    @Override
    public void onInitialize() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                applyEquipmentEffects(player);
            }
        });

        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (!(player instanceof ServerPlayerEntity serverPlayer) || world.isClient()) return;
            ItemStack tool = serverPlayer.getMainHandStack();
            int telepathy = level(tool, "Telepatía");
            int autoSmelt = level(tool, "Auto Fundir");
            if (telepathy > 0 || autoSmelt > 0) {
                collectNearbyDrops(serverPlayer, world, pos, telepathy > 0, autoSmelt);
            }
        });

        AttackEntityCallback.EVENT.register((player, world, hand, target, hitResult) -> {
            if (!(player instanceof ServerPlayerEntity attacker) || world.isClient()
                    || !(target instanceof LivingEntity living) || !living.isAlive()) {
                return ActionResult.PASS;
            }
            ItemStack weapon = attacker.getStackInHand(hand);
            if (!isSword(weapon)) return ActionResult.PASS;

            int vampire = level(weapon, "Vampiro");
            if (vampire > 0) attacker.heal(0.5f * vampire);

            int viper = level(weapon, "Viper");
            if (viper > 0) applyRandomViper(living, viper);

            int rage = level(weapon, "Rage");
            if (rage > 0) {
                long now = System.currentTimeMillis();
                RageState previous = RAGE.get(attacker.getUuid());
                int hits = previous == null || now - previous.lastHit() > 2000 ? 1 : Math.min(5, previous.hits() + 1);
                RAGE.put(attacker.getUuid(), new RageState(hits, now));
                double base = attacker.getAttributeValue(EntityAttributes.ATTACK_DAMAGE);
                float bonus = (float) (base * 0.12 * rage * hits);
                if (bonus > 0) living.damage(world.getDamageSources().playerAttack(attacker), bonus);
            }
            return ActionResult.PASS;
        });

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) -> {
            if (damageSource.getAttacker() instanceof ServerPlayerEntity player) {
                int exp = level(player.getMainHandStack(), "Experience");
                if (exp > 0) player.addExperience(2 * exp);
            }
        });

        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (!(entity instanceof ServerPlayerEntity player) || amount <= 0) return true;
            int savior = armorLevel(player, "Savior");
            int undyne = armorLevel(player, "Undyne");
            if (savior > 0 && chance(0.10 + 0.05 * (savior - 1))) return false;
            if (undyne > 0 && chance(0.05 * undyne)) {
                player.heal(4.0f);
                return false;
            }
            return true;
        });

        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (world.isClient() || !(player instanceof ServerPlayerEntity serverPlayer)) {
                return TypedActionResult.pass(player.getStackInHand(hand));
            }

            ItemStack held = serverPlayer.getStackInHand(hand);
            ItemStack other = serverPlayer.getStackInHand(hand == Hand.MAIN_HAND ? Hand.OFF_HAND : Hand.MAIN_HAND);

            if (isShopRocket(held)) {
                Category category = categoryFromShopRocket(held);
                if (category != null) {
                    ItemStack book = createRandomBook(category);
                    serverPlayer.setStackInHand(hand, ItemStack.EMPTY);
                    serverPlayer.giveItemStack(book);
                    serverPlayer.sendMessage(Text.literal("§aObtuviste un libro aleatorio de " + category.command + "."), true);
                    return TypedActionResult.success(ItemStack.EMPTY);
                }
            }

            if (isCustomBook(held) && canReceive(other, enchantmentFromBook(held))) {
                String enchantment = enchantmentFromBook(held);
                int enchantLevel = levelFromBook(held);
                if (enchantment != null && enchantLevel > 0) {
                    addEnchantment(other, enchantment, enchantLevel);
                    Hand targetHand = hand == Hand.MAIN_HAND ? Hand.OFF_HAND : Hand.MAIN_HAND;
                    serverPlayer.setStackInHand(targetHand, other);
                    serverPlayer.setStackInHand(hand, ItemStack.EMPTY);
                    serverPlayer.sendMessage(Text.literal("§aEncantamiento aplicado: " + enchantment + " " + roman(enchantLevel)), true);
                    return TypedActionResult.success(ItemStack.EMPTY);
                }
            }
            return TypedActionResult.pass(held);
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(literal("ce")
                .executes(context -> {
                    var source = context.getSource();
                    source.sendFeedback(() -> Text.literal("§6Tienda Custom Enchantments: §e/ce espada§7 (20 niveles), §e/ce herramientas§7 (25), §e/ce armadura§7 (25)."), false);
                    return 1;
                })
                .then(literal("espada").executes(context -> buyRocket(context.getSource().getPlayerOrThrow(), Category.SWORD)))
                .then(literal("herramientas").executes(context -> buyRocket(context.getSource().getPlayerOrThrow(), Category.TOOLS)))
                .then(literal("armadura").executes(context -> buyRocket(context.getSource().getPlayerOrThrow(), Category.ARMOR)))
            );
        });

        LOGGER.info("Custom Enchantments loaded: sword, armor, tools, books and XP shop.");
    }

    private static void applyEquipmentEffects(ServerPlayerEntity player) {
        ItemStack main = player.getMainHandStack();
        ItemStack off = player.getOffHandStack();
        applyHaste(player, main);
        applyHaste(player, off);

        ItemStack helmet = player.getEquippedStack(EquipmentSlot.HEAD);
        ItemStack chest = player.getEquippedStack(EquipmentSlot.CHEST);
        ItemStack legs = player.getEquippedStack(EquipmentSlot.LEGS);
        ItemStack boots = player.getEquippedStack(EquipmentSlot.FEET);

        if (level(helmet, "Glowing") > 0) effect(player, StatusEffects.NIGHT_VISION, 260, 0);
        if (level(chest, "ObsidianShield") > 0) effect(player, StatusEffects.FIRE_RESISTANCE, 60, 0);
        int springs = level(boots, "Resortes");
        if (springs > 0) effect(player, StatusEffects.JUMP_BOOST, 60, springs - 1);
        int health = Math.max(Math.max(level(helmet, "HealthBoost"), level(chest, "HealthBoost")),
                Math.max(level(legs, "HealthBoost"), level(boots, "HealthBoost")));
        if (health > 0) effect(player, StatusEffects.HEALTH_BOOST, 60, health - 1);
    }

    private static void applyHaste(ServerPlayerEntity player, ItemStack stack) {
        if (stack.isEmpty() || level(stack, "Haste") <= 0 || !isTool(stack)) return;
        effect(player, StatusEffects.HASTE, 60, level(stack, "Haste") - 1);
    }

    private static boolean isTool(ItemStack s) {
        return s.isOf(Items.WOODEN_PICKAXE) || s.isOf(Items.STONE_PICKAXE) || s.isOf(Items.IRON_PICKAXE)
            || s.isOf(Items.GOLDEN_PICKAXE) || s.isOf(Items.DIAMOND_PICKAXE) || s.isOf(Items.NETHERITE_PICKAXE)
            || s.isOf(Items.WOODEN_AXE) || s.isOf(Items.STONE_AXE) || s.isOf(Items.IRON_AXE)
            || s.isOf(Items.GOLDEN_AXE) || s.isOf(Items.DIAMOND_AXE) || s.isOf(Items.NETHERITE_AXE)
            || s.isOf(Items.WOODEN_SHOVEL) || s.isOf(Items.STONE_SHOVEL) || s.isOf(Items.IRON_SHOVEL)
            || s.isOf(Items.GOLDEN_SHOVEL) || s.isOf(Items.DIAMOND_SHOVEL) || s.isOf(Items.NETHERITE_SHOVEL);
    }

    private static boolean isSword(ItemStack s) {
        return s.isOf(Items.WOODEN_SWORD) || s.isOf(Items.STONE_SWORD) || s.isOf(Items.IRON_SWORD)
            || s.isOf(Items.GOLDEN_SWORD) || s.isOf(Items.DIAMOND_SWORD) || s.isOf(Items.NETHERITE_SWORD);
    }

    private static void effect(ServerPlayerEntity player, RegistryEntry<StatusEffect> effect, int duration, int amplifier) {
        player.addStatusEffect(new StatusEffectInstance(effect, duration, amplifier, true, false, true));
    }

    private static int armorLevel(ServerPlayerEntity player, String name) {
        return Math.max(Math.max(level(player.getEquippedStack(EquipmentSlot.HEAD), name),
                level(player.getEquippedStack(EquipmentSlot.CHEST), name)),
                Math.max(level(player.getEquippedStack(EquipmentSlot.LEGS), name),
                        level(player.getEquippedStack(EquipmentSlot.FEET), name)));
    }

    private static int level(ItemStack stack, String enchantment) {
        if (stack == null || stack.isEmpty() || enchantment == null) return 0;
        String name = stack.getName().getString().toLowerCase(Locale.ROOT);
        String target = (PREFIX + enchantment).toLowerCase(Locale.ROOT);
        int at = name.indexOf(target);
        if (at < 0) return 0;
        String tail = name.substring(at + target.length()).trim();
        for (int i = 5; i >= 1; i--) if (tail.startsWith(roman(i).toLowerCase(Locale.ROOT))) return i;
        return 1;
    }

    private static String roman(int level) {
        return switch (level) { case 1 -> "I"; case 2 -> "II"; case 3 -> "III"; case 4 -> "IV"; case 5 -> "V"; default -> "I"; };
    }

    private static void addEnchantment(ItemStack stack, String enchantment, int enchantLevel) {
        String current = stack.getName().getString();
        String entry = PREFIX + enchantment + " " + roman(enchantLevel);
        String updated;
        if (current.contains(entry)) updated = current;
        else if (current.startsWith(PREFIX)) updated = current + " | " + entry;
        else updated = entry + " | " + current;
        stack.set(net.minecraft.component.DataComponentTypes.CUSTOM_NAME, Text.literal(updated));
    }

    private static void collectNearbyDrops(ServerPlayerEntity player, World world, BlockPos pos, boolean telepathy, int autoSmelt) {
        Box area = new Box(pos).expand(1.6);
        List<ItemEntity> drops = world.getEntitiesByClass(ItemEntity.class, area, e -> e.isAlive());
        for (ItemEntity entity : drops) {
            ItemStack stack = entity.getStack();
            if (autoSmelt > 0 && chance(autoSmelt == 1 ? 0.25 : autoSmelt == 2 ? 0.50 : 1.0)) {
                entity.setStack(smeltCommonOreDrop(stack));
                stack = entity.getStack();
            }
            if (telepathy) {
                ItemStack remainder = stack.copy();
                player.getInventory().insertStack(remainder);
                if (remainder.isEmpty()) entity.discard();
                else entity.setStack(remainder);
            }
        }
    }

    private static ItemStack smeltCommonOreDrop(ItemStack stack) {
        Item result = null;
        if (stack.isOf(Items.RAW_IRON)) result = Items.IRON_INGOT;
        else if (stack.isOf(Items.RAW_GOLD)) result = Items.GOLD_INGOT;
        else if (stack.isOf(Items.RAW_COPPER)) result = Items.COPPER_INGOT;
        if (result != null) return new ItemStack(result, stack.getCount());
        return stack;
    }

    private static void applyRandomViper(LivingEntity target, int level) {
        int choice = ThreadLocalRandom.current().nextInt(3);
        int duration = 40 + level * 40;
        int amplifier = Math.max(0, level - 1);
        if (choice == 0) target.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, duration, amplifier));
        else if (choice == 1) target.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, duration, 0));
        else target.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, duration, amplifier));
    }

    private static boolean chance(double probability) {
        return ThreadLocalRandom.current().nextDouble() < probability;
    }

    private static int buyRocket(ServerPlayerEntity player, Category category) {
        if (player.experienceLevel < category.cost) {
            player.sendMessage(Text.literal("§cNecesitas " + category.cost + " niveles de experiencia."), false);
            return 0;
        }
        player.addExperienceLevels(-category.cost);
        ItemStack rocket = new ItemStack(Items.FIREWORK_ROCKET);
        rocket.set(net.minecraft.component.DataComponentTypes.CUSTOM_NAME,
                Text.literal(SHOP_MARKER + category.command));
        player.giveItemStack(rocket);
        player.sendMessage(Text.literal("§aCompraste un cohete de " + category.command + ". Haz clic derecho para obtener un libro aleatorio."), false);
        return 1;
    }

    private static ItemStack createRandomBook(Category category) {
        String enchantment = category.enchantments.get(ThreadLocalRandom.current().nextInt(category.enchantments.size()));
        int max = maxLevel(enchantment);
        int level = ThreadLocalRandom.current().nextInt(1, max + 1);
        ItemStack book = new ItemStack(Items.ENCHANTED_BOOK);
        book.set(net.minecraft.component.DataComponentTypes.CUSTOM_NAME,
                Text.literal(BOOK_MARKER + enchantment + " " + roman(level)));
        return book;
    }

    private static int maxLevel(String enchantment) {
        return switch (enchantment) {
            case "Vampiro", "Auto Fundir", "Haste", "Resortes", "HealthBoost", "Savior", "Undyne" -> 3;
            case "Experience", "Rage" -> 5;
            case "Viper" -> 3;
            default -> 1;
        };
    }

    private static boolean isShopRocket(ItemStack stack) {
        return !stack.isEmpty() && stack.isOf(Items.FIREWORK_ROCKET)
                && stack.getName().getString().startsWith(SHOP_MARKER);
    }

    private static Category categoryFromShopRocket(ItemStack stack) {
        String name = stack.getName().getString();
        for (Category c : Category.values()) if (name.equals(SHOP_MARKER + c.command)) return c;
        return null;
    }

    private static boolean isCustomBook(ItemStack stack) {
        return !stack.isEmpty() && stack.isOf(Items.ENCHANTED_BOOK)
                && stack.getName().getString().startsWith(BOOK_MARKER);
    }

    private static String enchantmentFromBook(ItemStack stack) {
        if (!isCustomBook(stack)) return null;
        String data = stack.getName().getString().substring(BOOK_MARKER.length()).trim();
        int split = data.lastIndexOf(' ');
        return split < 0 ? null : data.substring(0, split);
    }

    private static int levelFromBook(ItemStack stack) {
        if (!isCustomBook(stack)) return 0;
        String data = stack.getName().getString().substring(BOOK_MARKER.length()).trim();
        int split = data.lastIndexOf(' ');
        if (split < 0) return 0;
        String numeral = data.substring(split + 1);
        for (int i = 1; i <= 5; i++) if (roman(i).equals(numeral)) return i;
        return 0;
    }

    private static boolean canReceive(ItemStack target, String enchantment) {
        if (target == null || target.isEmpty() || enchantment == null) return false;
        return switch (enchantment) {
            case "Vampiro", "Experience", "Rage", "Viper" -> isSword(target);
            case "Auto Fundir", "Haste", "Telepatía" -> isTool(target);
            case "Glowing" -> target.isOf(Items.LEATHER_HELMET) || target.isOf(Items.CHAINMAIL_HELMET)
                    || target.isOf(Items.IRON_HELMET) || target.isOf(Items.GOLDEN_HELMET)
                    || target.isOf(Items.DIAMOND_HELMET) || target.isOf(Items.NETHERITE_HELMET) || target.isOf(Items.TURTLE_HELMET);
            case "ObsidianShield" -> target.isOf(Items.LEATHER_CHESTPLATE) || target.isOf(Items.CHAINMAIL_CHESTPLATE)
                    || target.isOf(Items.IRON_CHESTPLATE) || target.isOf(Items.GOLDEN_CHESTPLATE)
                    || target.isOf(Items.DIAMOND_CHESTPLATE) || target.isOf(Items.NETHERITE_CHESTPLATE);
            case "Resortes" -> target.isOf(Items.LEATHER_BOOTS) || target.isOf(Items.CHAINMAIL_BOOTS)
                    || target.isOf(Items.IRON_BOOTS) || target.isOf(Items.GOLDEN_BOOTS)
                    || target.isOf(Items.DIAMOND_BOOTS) || target.isOf(Items.NETHERITE_BOOTS);
            case "HealthBoost", "Savior", "Undyne" -> isArmor(target);
            default -> false;
        };
    }

    private static boolean isArmor(ItemStack s) {
        return s.isOf(Items.LEATHER_HELMET) || s.isOf(Items.CHAINMAIL_HELMET) || s.isOf(Items.IRON_HELMET)
            || s.isOf(Items.GOLDEN_HELMET) || s.isOf(Items.DIAMOND_HELMET) || s.isOf(Items.NETHERITE_HELMET)
            || s.isOf(Items.TURTLE_HELMET) || s.isOf(Items.LEATHER_CHESTPLATE) || s.isOf(Items.CHAINMAIL_CHESTPLATE)
            || s.isOf(Items.IRON_CHESTPLATE) || s.isOf(Items.GOLDEN_CHESTPLATE) || s.isOf(Items.DIAMOND_CHESTPLATE)
            || s.isOf(Items.NETHERITE_CHESTPLATE) || s.isOf(Items.LEATHER_LEGGINGS) || s.isOf(Items.CHAINMAIL_LEGGINGS)
            || s.isOf(Items.IRON_LEGGINGS) || s.isOf(Items.GOLDEN_LEGGINGS) || s.isOf(Items.DIAMOND_LEGGINGS)
            || s.isOf(Items.NETHERITE_LEGGINGS) || s.isOf(Items.LEATHER_BOOTS) || s.isOf(Items.CHAINMAIL_BOOTS)
            || s.isOf(Items.IRON_BOOTS) || s.isOf(Items.GOLDEN_BOOTS) || s.isOf(Items.DIAMOND_BOOTS)
            || s.isOf(Items.NETHERITE_BOOTS);
    }
}
