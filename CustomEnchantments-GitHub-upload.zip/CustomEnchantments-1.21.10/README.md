# Custom Enchantments — Fabric 1.21.10

Este proyecto conserva la configuración Gradle y el workflow `build.yml` del repositorio original.

## Funciones incluidas en esta primera compilación

Los efectos se activan al renombrar el objeto en un yunque con el nombre exacto indicado, incluyendo el prefijo `[CE]` y el nivel romano:

- `[CE] Haste I`, `[CE] Haste II`, `[CE] Haste III`: Prisa al sostener un pico, hacha o pala.
- `[CE] Glowing`: Visión nocturna con el casco equipado.
- `[CE] ObsidianShield`: Resistencia al fuego con la pechera equipada.
- `[CE] Resortes I` a `III`: Salto mejorado con las botas equipadas.
- `[CE] HealthBoost I` a `III`: efecto de salud extra mientras se lleva la pieza de armadura.
- `[CE] Telepatía`: intenta recoger los objetos que caen cerca al romper un bloque.
- `[CE] Auto Fundir I` a `III`: probabilidad de convertir hierro, oro y cobre en bruto que caen cerca en lingotes: 25%, 50% y 100%.

## Limitaciones conocidas

Esta versión NO implementa todavía libros encantados, tienda `/ce`, cohetes, interfaz de compra, ni los efectos Savior y Undyne. Los nombres `[CE]` son un mecanismo temporal de prueba, no encantamientos registrados de Minecraft. Auto Fundir solo reconoce hierro, oro y cobre en bruto; no aplica recetas generales de horno. HealthBoost utiliza el efecto vanilla de salud extra.

No se debe considerar una versión final hasta compilarla y probarla en un servidor Fabric 1.21.10.
