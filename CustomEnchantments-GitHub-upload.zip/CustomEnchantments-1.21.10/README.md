# Custom Enchantments — Minecraft 1.21.10 Fabric

## Estado de este paquete

Este ZIP contiene la **base técnica del proyecto**: configuración de Fabric/Loom, Java 21, metadatos del mod y GitHub Actions para compilar.

**Todavía no implementa las mecánicas del juego.** No lo instales en un servidor esperando que `/ce`, la tienda, los libros o los encantamientos ya funcionen. Esas partes se agregarán y probarán en los siguientes archivos.

## Versión objetivo

- Minecraft Java: 1.21.10
- Loader: Fabric
- Java: 21
- Fabric API: 0.138.4+1.21.10

## Funciones planificadas

### Espadas
- Vampiro I–IV
- Experience I–V
- Rage I–V (reinicio tras 2 segundos sin golpear)
- Viper I–III

### Herramientas
- Auto Fundir I–III
- Haste I–III
- Telepatía

### Armaduras
- Glowing (casco)
- ObsidianShield (pechera)
- Resortes I–III (botas)
- HealthBoost I–III
- Savior I–III
- Undyne I–III

### Tienda `/ce`
- Espadas: 20 niveles de experiencia
- Herramientas: 25 niveles
- Armaduras: 25 niveles
- Compra entrega una bola especial; clic derecho la convierte en un libro aleatorio de esa categoría.
- Todos los encantamientos de una categoría y todos sus niveles tendrán la misma probabilidad.
- Clic derecho con el libro sobre un objeto compatible aplica el encantamiento.

## Compilar en GitHub

1. Sube el contenido de este ZIP a la raíz de un repositorio.
2. Abre la pestaña **Actions**.
3. Ejecuta **Build Custom Enchantments** o haz un commit.
4. Si la compilación termina correctamente, descarga el artefacto `custom-enchantments-build`.
5. El `.jar` estará dentro de `build/libs/`.

## Importante

El workflow construye el código que exista en el repositorio. Que la compilación sea verde solo confirma que esa versión del código compila; no significa que las funciones planificadas ya estén implementadas.
